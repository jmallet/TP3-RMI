#!/bin/sh

java -jar graphe.jar <<EOF
1
EOF
