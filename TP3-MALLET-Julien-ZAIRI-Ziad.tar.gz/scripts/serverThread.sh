#!/bin/sh

java -jar server.jar <<EOF
1
EOF
