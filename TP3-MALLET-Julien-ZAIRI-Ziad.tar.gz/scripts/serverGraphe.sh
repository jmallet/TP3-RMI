#!/bin/sh

java -jar server.jar <<EOF
2
EOF
