/**
 * class used for test
 */
/**
 * @author julien
 *
 */
package test;