/**
 * class used for the server RMI
 */
/**
 * @author julien
 *
 */
package rmi;