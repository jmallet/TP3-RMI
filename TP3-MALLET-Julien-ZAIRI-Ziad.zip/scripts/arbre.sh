#!/bin/sh

java -jar arbre.jar <<EOF
0
EOF
