/**
 * main package to launch the server
 */
/**
 * @author julien
 *
 */
package server;